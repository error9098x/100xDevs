### FullStack Development Course Assignments (Week 1)

- The project contains easy, medium and hard assigments for week 1.
- 01-js contains assignments related to JavaScript, things that were covered in the first class.
- 02-async-js contains assignments related to asynchronous JavaScript, things that were covered in the second class.
- If you have any query then ping us on the Discord server.